this is part of a webproxy written in C++

Building:
you can use the provided makefile to building the program

running:
use make run to run the file on port 10480, or use ./a.out <port> where port is a port number that you also configure in the proxy settings to your browser
